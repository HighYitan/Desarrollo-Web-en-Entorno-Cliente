export default function Footer(){
    return(
        <footer className="text-center bg-light py-3">
            <p>© 2024 Star Wars Figures. All rights reserved.</p>
        </footer>
    )
}