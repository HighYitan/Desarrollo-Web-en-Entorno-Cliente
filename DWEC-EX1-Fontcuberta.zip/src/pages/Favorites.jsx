export default function Favorites(){
    return(
        <div>Página de Favoritos</div>
    )
}