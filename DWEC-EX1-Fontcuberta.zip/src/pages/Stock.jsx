export default function Stock(){
    return(
        <div>Página de Stock</div>
    )
}